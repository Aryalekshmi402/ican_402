Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yssyogesh@makitweb.com
Tutorial Link: http://makitweb.com/make-photo-gallery-from-image-directory-with-php/

